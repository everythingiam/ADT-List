package treeCursor3;

public class Tree {
    private static class Node { // узел дерева
        int rightBrother; // правый брат
        int leftSon; // левый сын
        char label; // значение
        private Node(int rightBrother, int leftSon, char label) {
            this.rightBrother= rightBrother;
            this.leftSon = leftSon;
            this.label = label;
        }
    }

    private int root; // корень
    private final static Node[] array; // массив значений
    private static int SPACE; // первый свободный
    private final static int length = 10; // длина массива

    static { // инициализация массива
        array = new Node[length];
        SPACE = 0;
        for (int i = 0; i < length-1; i ++)
            array[i] = new Node(-1, i+1, '\u0000');
        array[length-1] = new Node(-1, -1, '\u0000');
    }

    public Tree() {
        root = -1; // дерево пустое
    }


    // Возвращает родителя узла с позицией n, начиная с корня дерева.
    public int PARENT(int n) {
        if (n == root)
            return -1;
        return getParent(n, root);
    }

    // Возвращает левого сына узла с позицией n.
    public int LEFTMOSTCHILD(int n) {
        if (root == -1)
            return -1;
        if (n == root)
            return array[root].leftSon;
        int temp = getParent(n, root);
        if (temp != -1)
            return array[n].leftSon;
        return -1;
    }

    // Возвращает правого брата узла с позицией n.
    public int RIGHTSIBLING(int n) {
        int temp = getParent(n, root);
        if (temp == -1)
            return -1;
        temp = array[temp].leftSon;
        while (temp != n)
            temp = array[temp].rightBrother;
        return array[temp].rightBrother;
    }

    // Возвращает значение узла с позицией n.
    public char LABEL(int n) {
        if (n == root)
            return array[n].label;
        int temp = getParent(n, root);
        if (temp != -1)
            return array[n].label;
        return '\u0000';
    }

    // Создает новый корень со значением v.
    public Tree CREATE(char v) {
        array[SPACE].label = v;
        int temp = SPACE;
        SPACE = array[SPACE].leftSon;
        if (root != -1)
            array[temp].leftSon = root;
        else
            array[temp].leftSon = -1;
        root = temp;
        return this;
    }

    // Создает новый корень и два поддерева.
    public Tree CREATE(char v, Tree t) {
        if (root == -1)
            return t.CREATE(v);
        if (t.root == -1 || t == this)
            return CREATE(v);
        int temp = SPACE;
        SPACE = array[SPACE].leftSon;
        array[temp].label = v;
        array[temp].leftSon = root;
        array[root].rightBrother = t.root;
        root = temp;
        t.root = -1;
        return this;
    }

    // Возвращает позицию корня дерева.
    public int ROOT() {
        return root;
    }

    // Очищает дерево.
    public void MAKENULL() {
        if (root != -1) {
            clearTree(root);
            root = -1;
        }
    }

    // Поиск родителя узла в дереве по его позиции и текущему корню дерева.
    private int getParent(int position, int currRoot) {
        int son = array[currRoot].leftSon;
        while (son != -1) {
            if (position == son)
                return currRoot;
            int temp = getParent(position, son);
            if (temp != -1)
                return temp;
            son = array[son].rightBrother;
        }
        return -1;
    }

    // Очистка поддерева с корнем в currRoot.

    private void clearTree(int currRoot) {
        int son = array[currRoot].leftSon;
        while (son != -1) {
            clearTree(son);
            son = array[son].rightBrother;
        }
        array[root].leftSon = SPACE;
        SPACE = currRoot;
    }

    // Выводит значения, левого сына и правого брата для каждого узла в дереве.
    public void print() {
        for (int i = 0; i < length; i++){
            System.out.println(i + ": " + array[i].label + " " + array[i].leftSon + " " + array[i].rightBrother);
        }
        System.out.println();
    }
}

