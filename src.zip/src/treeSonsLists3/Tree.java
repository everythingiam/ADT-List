package treeSonsLists3;

public class Tree {
    private static class Node { // узел дерева
        private int pos; // позиция
        private SonNode sonsList; // список сыновей
        private char label; // значение
        public Node(int pos, char label) {
            this.pos = pos;
            this.label = label;
        }
    }

    private static class SonNode { // элемент списка сыновей
        private final int pos; // позиция
        private final SonNode next; // ссылка на следующий элемент списка
        public SonNode(int pos, SonNode next) {
            this.pos = pos;
            this.next = next;
        }
    }

    private int root; // корень
    private final static Node[] array; // массив значений
    private static int SPACE; // первый свободный
    private final static int length = 10; // длина массива

    static { // инициализация массива
        array = new Node[length];
        SPACE = 0;
        for (int i=0; i < length-1; i++){
            array[i] = new Node(i+1, '\u0000');
        }
        array[length-1] = new Node(-1, '\u0000');
    }

    public Tree() {
        root = -1; // дерево пустое
    }


// Возвращает родителя узла с позицией n, начиная с корня дерева.
    public int PARENT(int n) {
        if (n == root)
            return -1;
        return getParent(n, root);
    }

// Возвращает левого сына узла с позицией n.
    public int LEFTMOSTCHILD(int n) {
        if (root == -1)
            return -1;
        if (n == root)
            return array[n].sonsList.pos;
        int temp = getParent(n, root);
        if (temp != -1 && array[n].sonsList != null)
            return array[n].sonsList.pos;
        return -1;
    }

    // Возвращает правого брата узла с позицией n.
    public int RIGHTSIBLING(int n) {
        int temp = getParent(n, root);
        if (temp == -1)
            return -1;
        SonNode son = array[temp].sonsList;
        while (son.pos != n)
            son = son.next;
        if (son.next != null)
            return son.next.pos;
        return -1;
    }

// Возвращает значение узла с позицией n.
    public char LABEL(int n) {
        if (n == root)
            return array[n].label;
        int temp = getParent(n, root);
        if (temp != -1)
            return array[n].label;
        return '\u0000';
    }

// Создает новый корень со значением v.
    public Tree CREATE(char v) {
        if (root != -1)
            array[SPACE].sonsList = new SonNode(root, null);
        array[SPACE].label = v;
        root = SPACE;
        SPACE = array[SPACE].pos;
        return this;
    }

// Создает новый корень и два поддерева.
    public Tree CREATE(char v, Tree t) {
        if (root == -1)
            return t.CREATE(v);
        if (t.root == -1 || t == this)
            return CREATE(v);
        array[SPACE].label = v;
        array[SPACE].sonsList = new SonNode(root, new SonNode(t.root, null));
        root = SPACE;
        SPACE = array[SPACE].pos;
        return this;
    }

// Возвращает позицию корня дерева.
    public int ROOT() {
        return root;
    }

// Очищает дерево.
    public void MAKENULL() {
        if (root != -1) {
            clearTree(root);
            root = -1;
        }
    }

// Выводит значения, левого сына и правого брата для каждого узла в дереве.
    public void print() {
        for (int i = 0; i < length; i++) {
            System.out.println(i + ": " + array[i].label + " -> " + getSonList(array[i].sonsList));
        }
        System.out.println();
    }

//    /**
//     * Метод, который принимает список сыновей SonNode и форматирует его в виде строки.
//     * Использует цикл, чтобы пройти по всем элементам списка сыновей и добавить их позиции в строку.
//     * Возвращает строку, представляющую список сыновей.
//     */
    private static String getSonList(SonNode sonList) {
        String sonListString = "";
        while (sonList != null) {
            sonListString += sonList.pos + " -> ";
            sonList = sonList.next;
        }
        sonListString += " ";
        return sonListString;
    }

// Поиск родителя узла в дереве по его позиции и текущему корню дерева.
    private int getParent(int position, int currRoot) {
        SonNode son = array[currRoot].sonsList;
        while (son != null) {
            if (son.pos == position)
                return currRoot;
            int temp = getParent(position, son.pos);
            if (temp == -1)
                son = son.next;
            else return temp;
        }
        return -1;
    }

// Очистка поддерева с корнем в currRoot.

    private void clearTree(int currRoot) {
        SonNode son = array[currRoot].sonsList;
        while (son != null) {
            clearTree(son.pos);
            son = son.next;
        }
        array[currRoot].pos = SPACE;
        SPACE = currRoot;
    }
}
