package Mains;
//import treeSonsLists3.Tree;
import treeCursor3.Tree;
public class MainTrees3 {
    public static void main(String[] args) {
        Tree tree1 = new Tree();
        tree1.CREATE('B');

        Tree tree2 = new Tree();
        tree2.CREATE('D');
        tree2.CREATE('C');

        tree1.CREATE('A', tree2);

        tree2 = new Tree();
        tree2.CREATE('H');
        tree2.CREATE('G', new Tree().CREATE('I'));

        Tree tree3 = new Tree();
        tree3.CREATE('F');
        tree3.CREATE('E', tree2);

        tree1.CREATE('T', tree3);

        System.out.println("Структура дерева:");
        tree1.print();

        System.out.println("Симметричный обход дерева:");
        symmetric(tree1, tree1.ROOT());

    }

    static void symmetric(Tree tree, int root) {
        if (root != -1) {
            int temp = tree.LEFTMOSTCHILD(root);
            symmetric(tree, temp);
            System.out.println(tree.LABEL(root));
            while (temp != -1) {
                temp = tree.RIGHTSIBLING(temp);
                symmetric(tree, temp);
            }
        }
    }
}
