package arrayList1;
import postcard.Postcard;


public class PostcardObject {
    public Postcard cardObject;

    public PostcardObject(Postcard postcard){
        cardObject = postcard;
    }
}
